# ISDA CDM&trade; Generated Java Usage Examples

This project demonstrates functionality of the generated code artifacts of the ISDA Common Domain Model&trade; 

## Dependencies

Code dependencies can be found on the Rosetta Portal [here](https://home.rosetta-model.org/#/home).  For access to the Rosetta Portal, please contact MarketInfrastructureandTechnology@isda.org.

### Maven
A `settings.xml` file is provided in the project root directory, use it install dependencies as below: 
```bash
mvn -s settings.xml clean install

```
